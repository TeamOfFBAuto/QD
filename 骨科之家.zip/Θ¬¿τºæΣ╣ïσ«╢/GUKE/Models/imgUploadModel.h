//
//  imgUploadModel.h
//  GUKE
//
//  Created by ianMac on 14-9-26.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface imgUploadModel : NSObject
@property (nonatomic, strong) NSString *imageName;
@property (nonatomic, strong) NSData *imageData;
@end
