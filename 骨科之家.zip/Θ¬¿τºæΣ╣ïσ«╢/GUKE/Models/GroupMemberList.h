//
//  GroupMemberList.h
//  UNITOA
//
//  Created by qidi on 14-7-9.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GroupMemberList : NSObject
@property(nonatomic ,strong)NSString *addTime;// 加入时间
@property(nonatomic ,strong)NSString *denytalk;
@property(nonatomic ,strong)NSString *firstname;// 用户姓名
@property(nonatomic ,strong)NSString *isCreator;// 管理员是否为
@property(nonatomic ,strong)NSString *membermemo;
@property(nonatomic ,strong)NSString *userId;
@property(nonatomic ,strong)NSString *username;// 用户名
@property(nonatomic ,strong)NSString *icon;// 群组名

@end
