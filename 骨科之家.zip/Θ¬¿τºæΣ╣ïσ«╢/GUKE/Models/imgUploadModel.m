//
//  imgUploadModel.m
//  GUKE
//
//  Created by ianMac on 14-9-26.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "imgUploadModel.h"

@implementation imgUploadModel

@end
