//
//  Contactlist.h
//  leliao
//
//  Created by qidi on 14-6-24.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Contactlist : NSObject
@property(nonatomic ,strong)NSString *context;
@property(nonatomic ,strong)NSString *lastReply;
@property(nonatomic ,strong)NSString *recvFirstname;
@property(nonatomic ,strong)NSString *recvId;
@property(nonatomic ,strong)NSString *title;
@end
