//
//  GroupMemberList.m
//  UNITOA
//
//  Created by qidi on 14-7-9.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "GroupMemberList.h"

@implementation GroupMemberList

@end
