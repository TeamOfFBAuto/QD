//
//  dateAndContent.h
//  UNITOA
//
//  Created by ianMac on 14-9-2.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface dateAndContent : NSObject
@property (nonatomic,strong)NSString *time;
@property (nonatomic,strong)NSMutableArray *array;
@end
