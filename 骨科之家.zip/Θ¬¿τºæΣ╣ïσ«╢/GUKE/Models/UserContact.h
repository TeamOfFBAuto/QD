//
//  UserContact.h
//  leliao
//
//  Created by qidi on 14-6-24.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserContact : NSObject
@property(nonatomic, strong) NSString *contactId;
@property(nonatomic, strong) NSString *contactName;
@property(nonatomic, strong) NSString *contactType;
@property(nonatomic, strong) NSString *contactUsername;
@property(nonatomic, strong) NSString *createDate;
@property(nonatomic, strong) NSString *creator;
@property(nonatomic, strong) NSString *creatorName;
@property(nonatomic, strong) NSString *creatorUsername;
@property(nonatomic, strong) NSString *lastMsg;
@property(nonatomic, strong) NSString *groupType;
@property(nonatomic, strong) NSString *lastMsgTime;
@property(nonatomic, strong) NSString *lastMsgUser;
@property(nonatomic, strong) NSString *lastMsgUserFirstname;
@property(nonatomic, strong) NSString *lastMsgUserUsername;
@property(nonatomic, strong) NSString *memo;
@property(nonatomic, strong) NSString *icon;
@property(nonatomic, strong) NSString *isTop;
@property(nonatomic, strong) NSString *topOperateTime;
@property(nonatomic, strong) NSString *isMute;
@property(nonatomic, strong) NSString *lastMsgNum;
@property(nonatomic, strong) NSString *filename;

@property (nonatomic,retain) NSString *creatDate;

@property (nonatomic,retain) NSString *uid;//客服端对应的唯一标识  自己定义的

//发送文本类型
@property (nonatomic,retain) NSString *context;

@property (nonatomic,retain) NSString *typeId;//消息分类 ，群聊，私聊之类的

@property (nonatomic,retain) NSString *firstUsername;

@end
