//
//  UIActionSheet_UISheet.h
//  UNITOA
//
//  Created by qidi on 14-9-3.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIActionSheet ()
@property(nonatomic, strong)id object;
@property(nonatomic, strong)NSDictionary *Info;
@end
