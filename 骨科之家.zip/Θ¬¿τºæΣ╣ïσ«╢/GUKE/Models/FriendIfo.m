//
//  FriendIfo.m
//  UNITOA
//
//  Created by qidi on 14-6-25.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "FriendIfo.h"

@implementation FriendIfo
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}
@end
