//
//  UserIfo.m
//  leliao
//
//  Created by qidi on 14-6-23.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "UserIfo.h"

@implementation UserIfo
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}
@end
