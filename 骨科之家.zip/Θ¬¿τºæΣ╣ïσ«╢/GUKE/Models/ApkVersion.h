//
//  ApkVersion.h
//  UNITOA
//
//  Created by qidi on 14-6-27.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ApkVersion : NSObject
@property(nonatomic, strong)NSString *code;
@property(nonatomic, strong)NSString *status;
@property(nonatomic, strong)NSString *url;
@property(nonatomic, strong)NSString *version;
@property(nonatomic, strong)NSString *versiondesc;
@property(nonatomic, strong)NSString *versionsize;
@property(nonatomic, strong)NSString *versionsizestr;
@end
