//
//  GroupIfo.m
//  UNITOA
//
//  Created by qidi on 14-7-12.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "GroupIfo.h"

@implementation GroupIfo

@end
