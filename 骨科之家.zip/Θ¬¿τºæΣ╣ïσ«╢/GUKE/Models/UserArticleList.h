//
//  UserArticleList.h
//  UNITOA
//
//  Created by qidi on 14-7-14.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserArticleList : NSObject
@property(nonatomic, strong)NSString *articleId;
@property(nonatomic, strong)NSString *context;
@property(nonatomic, strong)NSString *createDate;
@property(nonatomic, strong)NSString *deleteFlag;
@property(nonatomic, strong)NSString *isShare;
@property(nonatomic, strong)NSString *photo;
@property(nonatomic, strong)NSString *imageWidth;
@property(nonatomic, strong)NSString *imageHeight;
@property(nonatomic, strong)NSString *shareUrl;
@property(nonatomic, strong)NSString *userId;
@property(nonatomic, strong)NSString *username;
@property(nonatomic, strong)NSMutableArray *commentArray;
@property(nonatomic, strong)NSMutableArray *goodArray;
@property(nonatomic, strong)NSMutableArray *allCommentArray;
@property(nonatomic, strong)NSMutableArray *allGoodArray;
///多个文件
@property(nonatomic,strong)NSMutableArray * attachlistArray;
@property(nonatomic, strong)NSString *iconUrl;

@end
