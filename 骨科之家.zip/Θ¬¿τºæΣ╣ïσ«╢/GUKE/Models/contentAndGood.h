//
//  contentAndGood.h
//  UNITOA
//
//  Created by qidi on 14-7-14.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface contentAndGood : NSObject
@property(nonatomic, strong)NSString *articleId;// 被评论文章id
@property(nonatomic, strong)NSString *articleUserId;// 文章创建者的id
@property(nonatomic, strong)NSString *commentId;// 评论内容id
@property(nonatomic, strong)NSString *commentType;// 评论类型，0：文字评论；1：赞
@property(nonatomic, strong)NSString *context;// 评论内容
@property(nonatomic, strong)NSString *createDate;// 评论日期
@property(nonatomic, strong)NSString *deleteFlag;// 是否有删除权限
@property(nonatomic, strong)NSString *userId;// 评论人
@property(nonatomic, strong)NSString *iconUrl;// 头像连接
@property(nonatomic, strong)NSString *userName;// 评论人姓名
@end
