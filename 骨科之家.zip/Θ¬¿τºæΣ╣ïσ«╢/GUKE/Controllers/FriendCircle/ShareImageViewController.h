//
//  ShareImageViewController.h
//  UNITOA
//
//  Created by qidi on 14-7-16.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
@interface ShareImageViewController : UIViewController<UITextViewDelegate,MBProgressHUDDelegate>
@property(nonatomic, strong)UIImage *img;
@property(nonatomic, strong)NSData *imgData;
@end
