//
//  PostMoodViewController.h
//  UNITOA
//
//  Created by qidi on 14-7-15.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
@interface PostMoodViewController : UIViewController<UITextViewDelegate,MBProgressHUDDelegate>

@end
