//
//  ShareUrlViewController.h
//  UNITOA
//
//  Created by qidi on 14-7-16.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
@interface ShareUrlViewController : UIViewController<UITextViewDelegate,MBProgressHUDDelegate>

@end
