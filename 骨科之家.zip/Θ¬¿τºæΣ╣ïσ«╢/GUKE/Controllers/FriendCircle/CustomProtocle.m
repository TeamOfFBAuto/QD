//
//  CustomProtocle.m
//  GUKE
//
//  Created by qidi on 14-10-11.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol FriendCircel <NSObject>

@optional
- (void)refreshData;
@end