//
//  AddNewColleagueViewController.h
//  UNITOA
//  添加新同事
//  Created by ianMac on 14-7-22.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FriendIfo;

@interface AddNewColleagueViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>
{
    UITableView *_tableView;
    
    NSMutableArray *_dataArray;
    
    FriendIfo *_friendModelTemp;
}
- (void)requestData;
@end
