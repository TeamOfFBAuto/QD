//
//  DelGroupMemberViewController.h
//  UNITOA
//
//  Created by qidi on 14-7-11.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddGroupMemberTableViewCell.h"
#import "MBProgressHUD.h"
@interface DelGroupMemberViewController : UIViewController<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate,CheckBoxDelegate,MBProgressHUDDelegate>
@property(nonatomic, strong)NSString *groupId;
@property(nonatomic, strong)NSString *groupName;
@end
