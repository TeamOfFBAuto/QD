//
//  RegisterViewController.h
//  UnisLiCai
//
//  Created by tusinfo on 14-9-25.
//  Copyright (c) 2014年 tusinfo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterViewController : UIViewController<UITextFieldDelegate,UIScrollViewDelegate,UIAlertViewDelegate,UITextViewDelegate>

@end
