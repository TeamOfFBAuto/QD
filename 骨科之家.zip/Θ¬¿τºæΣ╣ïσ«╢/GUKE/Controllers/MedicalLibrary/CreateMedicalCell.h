//
//  CreateMedicalCell.h
//  GUKE
//
//  Created by soulnear on 14-10-1.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreateMedicalCell : UITableViewCell



@property (strong, nonatomic) UILabel *title_label;

@property (strong, nonatomic) UITextView *input_textView;

@property (strong, nonatomic) UIImageView *input_line_view;






@end
