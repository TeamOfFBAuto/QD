//
//  RemindViewController.h
//  WeiTongShi
//
//  Created by qidi on 14-6-4.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RemindViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@end
