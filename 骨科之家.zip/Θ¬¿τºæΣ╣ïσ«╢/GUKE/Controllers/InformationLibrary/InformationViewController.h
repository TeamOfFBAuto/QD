//
//  InformationViewController.h
//  GUKE
//  资料库
//  Created by ianMac on 14-9-24.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CreatNewInfoViewController.h"
#import "InfoDetailViewController.h"
@interface InformationViewController : UIViewController<InfoDetailViewDelegate,CreatNewInfoViewDelegate>

@end
