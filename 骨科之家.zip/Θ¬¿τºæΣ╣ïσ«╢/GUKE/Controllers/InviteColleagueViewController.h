//
//  InviteColleagueViewController.h
//  WeiTongShi
//
//  Created by qidi on 14-6-4.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RadioButton.h"
@interface InviteColleagueViewController : UIViewController<RadioButtonDelegate>

@end
