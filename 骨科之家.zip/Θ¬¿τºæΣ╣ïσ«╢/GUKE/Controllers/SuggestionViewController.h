//
//  SuggestionViewController.h
//  UNITOA
//
//  Created by qidi on 14-6-27.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SuggestionViewController : UIViewController<UITextViewDelegate>

@end
