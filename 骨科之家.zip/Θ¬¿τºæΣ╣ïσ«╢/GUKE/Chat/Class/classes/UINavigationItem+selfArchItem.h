//
//  UINavigationItem+selfArchItem.h
//  VColleagueChat
//
//  Created by lqy on 4/22/14.
//  Copyright (c) 2014 laimark.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationItem (selfArchItem)
- (UILabel *)selfArchSetTitle:(NSString *)titel;
- (void)selfArchSetReturnAnimated:(BOOL)animated Sel:(SEL)sel target:(id)target;
@end
