//
//  HttpRequsetFactory.h
//  VColleagueChat
//
//  Created by lqy on 4/29/14.
//  Copyright (c) 2014 laimark.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIFormDataRequest.h"
//#import "SBJson.h"
@interface HttpRequsetFactory : NSObject
+(NSMutableDictionary *)requestCommon;
+ (ASIFormDataRequest *)getRequestKeys:(NSDictionary *)keyDic subUrl:(NSString *)suburl userCommon:(BOOL)con;
@end
