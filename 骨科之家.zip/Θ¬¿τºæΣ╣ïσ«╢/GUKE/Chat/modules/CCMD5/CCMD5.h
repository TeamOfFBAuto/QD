//
//  CCMD5.h
//  EnglishClicent
//
//  Created by Ming Zhang on 14-3-10.
//  Copyright (c) 2014年 laimark.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CCMD5 : NSObject
+ (NSString *)CCMDPathForKey:(NSString *)key;
+ (NSString *)CCMDPathForData:(NSData *)data;
@end
