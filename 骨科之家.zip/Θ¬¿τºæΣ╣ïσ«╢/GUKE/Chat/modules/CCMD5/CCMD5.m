//
//  CCMD5.m
//  EnglishClicent
//
//  Created by Ming Zhang on 14-3-10.
//  Copyright (c) 2014年 laimark.com. All rights reserved.
//

#import "CCMD5.h"
#import <CommonCrypto/CommonDigest.h>
@implementation CCMD5
+ (NSString *)CCMDPathForKey:(NSString *)key{
    const char *str = [key UTF8String];
    unsigned char r[CC_MD5_DIGEST_LENGTH];
    CC_MD5(str, (CC_LONG)strlen(str), r);
    NSString *filename = [NSString stringWithFormat:@"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
                          r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13], r[14], r[15]];
    return filename;
}
+ (NSString*)CCMDPathForData:(NSData *)data
{
    unsigned char result[16];
    CC_MD5( data.bytes, data.length, result ); // This is the md5 call
    return [NSString stringWithFormat:
            @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
            result[0], result[1], result[2], result[3],
            result[4], result[5], result[6], result[7],
            result[8], result[9], result[10], result[11],
            result[12], result[13], result[14], result[15]
            ];
}
@end
