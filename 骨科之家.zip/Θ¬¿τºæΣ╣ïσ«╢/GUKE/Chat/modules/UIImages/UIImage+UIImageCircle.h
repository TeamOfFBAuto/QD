//
//  UIImage+UIImageCircle.h
//  Starway
//
//  Created by Ming Zhang on 13-7-26.
//  Copyright (c) 2013年 laimark.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (UIImageCircle)
-(UIImage *)imageCircleWithBoderWidth:(CGFloat)boder withShadow:(CGFloat)shadow;
-(UIImage *)imageCircle;
@end
