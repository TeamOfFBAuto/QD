//
//  UIImage+fixOrientation.h
//  Starway
//
//  Created by Ming Zhang on 13-7-24.
//  Copyright (c) 2013年 laimark.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (fixOrientation)
-(UIImage *)fixOrientation;
@end
