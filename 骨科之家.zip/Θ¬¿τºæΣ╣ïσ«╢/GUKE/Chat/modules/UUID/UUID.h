//
//  UUID.h
//  VColleagueChat
//
//  Created by lqy on 4/24/14.
//  Copyright (c) 2014 laimark.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UUID : NSObject
+ (NSString *)createUUID;
@end
