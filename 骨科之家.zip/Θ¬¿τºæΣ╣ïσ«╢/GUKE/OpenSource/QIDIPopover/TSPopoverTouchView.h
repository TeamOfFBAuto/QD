//
//  TSPopoverTouchView.h
//
//  Created by Saito Takashi on 5/9/12.
//  Copyright (c) 2012 synetics ltd. All rights reserved.
//
// https://github.com/takashisite/TSPopover
//

#import <UIKit/UIKit.h>
#import "TSPopoverTouchesDelegate.h"

@interface TSPopoverTouchView : UIView

@property (strong,nonatomic) id delegate;

@end
