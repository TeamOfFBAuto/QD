//
//  getAppInfo.h
//  UNITOA
//
//  Created by qidi on 14-8-30.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface getAppInfo : NSObject
+ (void)getAppVersion;
+ (void)getDataBaseVersion:(NSInteger)version;
@end
