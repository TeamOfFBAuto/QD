//
//  SqliteClass.h
//  UNITOA
//
//  Created by qidi on 14-7-22.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#define USERIFO_TABLE        @"userInfo"
#define USERCONTACT_TABLE    @"userContact"
#define USERADDEDGROUP_TABLE @"userAddedGroup"
#define GROUPMEMBER_TABLE    @"groupMember"
@interface SqliteClass : NSObject
+ (NSString *)querAndCreatDatabasePath;
+ (FMDatabase *)creatDataBase:(NSString *)table andkeyArray:(NSArray *)key;


@end
