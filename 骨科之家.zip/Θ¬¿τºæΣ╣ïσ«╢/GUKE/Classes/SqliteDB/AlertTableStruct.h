//
//  AlertTableStruct.h
//  UNITOA
//
//  Created by qidi on 14-9-1.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "FMDatabaseQueue.h"
#define USERIFO_TABLE        @"userInfo"
#define USERCONTACT_TABLE    @"userContact"
#define USERADDEDGROUP_TABLE @"userAddedGroup"
#define GROUPMEMBER_TABLE    @"groupMember"
#define TABLE_HD             @"hdtable"
@interface AlertTableStruct : NSObject
+ (void)creatTableStruct:(NSInteger)versionNum;
@end
