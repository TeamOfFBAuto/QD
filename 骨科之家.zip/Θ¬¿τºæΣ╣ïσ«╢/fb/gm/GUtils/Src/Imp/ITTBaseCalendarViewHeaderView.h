//
//  BaseCalendarViewHeaderView.h
//  ZHJCalendar
//
//  Created by huajian zhou on 12-4-12.
//  Copyright (c) 2012年 itotemstudio. All rights reserved.
//

#import "ITTCalendarViewHeaderView.h"

@interface ITTBaseCalendarViewHeaderView : ITTCalendarViewHeaderView

@end
