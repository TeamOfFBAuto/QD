//
//  BiaoQianBottomView.m
//  GUKE
//
//  Created by szk on 14-10-3.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "BiaoQianBottomView.h"

@implementation BiaoQianBottomView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
