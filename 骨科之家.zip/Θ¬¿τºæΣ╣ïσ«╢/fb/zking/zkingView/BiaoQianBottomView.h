//
//  BiaoQianBottomView.h
//  GUKE
//
//  Created by szk on 14-10-3.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BiaoQianBottomView : UIView



@end
