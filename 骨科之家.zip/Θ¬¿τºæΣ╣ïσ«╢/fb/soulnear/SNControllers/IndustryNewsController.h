//
//  IndustryNewsController.h
//  GUKE
//
//  Created by soulnear on 14-9-30.
//  Copyright (c) 2014年 qidi. All rights reserved.
//
/*
 **业界动态
 */
#import <UIKit/UIKit.h>

@interface IndustryNewsController : SNViewController
{
    
}

@end
