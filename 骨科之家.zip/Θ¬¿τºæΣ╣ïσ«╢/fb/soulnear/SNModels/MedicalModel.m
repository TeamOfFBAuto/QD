//
//  MedicalModel.m
//  GUKE
//
//  Created by soulnear on 14-10-1.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import "MedicalModel.h"

@implementation MedicalModel

@end
