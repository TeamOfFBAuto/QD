//
//  SNViewController.h
//  GUKE
//
//  Created by soulnear on 14-10-3.
//  Copyright (c) 2014年 qidi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SNViewController : UIViewController

@property(nonatomic,strong)NSString * aTitle;


-(void)setATitle:(NSString *)aTitle;

@end
